fx_version 'cerulean'
games { 'gta5' }

author 'jim-g'
description 'JIM GORDON THE ONE AND ONLY'
version '1.0'

this_is_a_map 'yes'