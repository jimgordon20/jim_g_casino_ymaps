// shity_casino_ymaps //

Creator: Jim-G

full: jimgordontheoneandonly

Description: [and a shitty ymap map for the casino because people think it's okay to charge money for it, so i taken 5% more effort than he did.]